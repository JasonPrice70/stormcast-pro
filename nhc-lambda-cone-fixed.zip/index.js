const axios = require('axios');
const yauzl = require('yauzl');
const xml2js = require('xml2js');

// NHC API endpoints
const NHC_BASE_URL = 'https://www.nhc.noaa.gov';

// Request timeout (30 seconds)
const REQUEST_TIMEOUT = 30000;

// CORS headers for browser compatibility
const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'Content-Type,X-Amz-Date,Authorization,X-Api-Key,X-Amz-Security-Token',
  'Access-Control-Allow-Methods': 'GET,OPTIONS',
  'Content-Type': 'application/json'
};

/**
 * Parse KMZ file and extract track data as GeoJSON
 */
async function parseKmzToTrackGeoJSON(kmzBuffer) {
  return new Promise((resolve, reject) => {
    yauzl.fromBuffer(kmzBuffer, { lazyEntries: true }, (err, zipfile) => {
      if (err) {
        console.error('Error opening KMZ file:', err);
        return reject(err);
      }

      let kmlContent = '';
      
      zipfile.readEntry();
      zipfile.on('entry', (entry) => {
        if (entry.fileName.toLowerCase().endsWith('.kml')) {
          zipfile.openReadStream(entry, (err, readStream) => {
            if (err) {
              console.error('Error reading KML from KMZ:', err);
              return reject(err);
            }

            const chunks = [];
            readStream.on('data', (chunk) => chunks.push(chunk));
            readStream.on('end', () => {
              kmlContent = Buffer.concat(chunks).toString('utf8');
              zipfile.readEntry();
            });
            readStream.on('error', reject);
          });
        } else {
          zipfile.readEntry();
        }
      });

      zipfile.on('end', () => {
        if (!kmlContent) {
          return reject(new Error('No KML file found in KMZ'));
        }

        // Parse KML and extract track data
        extractTrackFromKML(kmlContent)
          .then(resolve)
          .catch(reject);
      });

      zipfile.on('error', reject);
    });
  });
}

/**
 * Extract track data from KML content
 */
async function extractTrackFromKML(kmlContent) {
  try {
    const parser = new xml2js.Parser({ explicitArray: false });
    const result = await parser.parseStringPromise(kmlContent);

    // Find track placemarks in KML
    const features = [];
    
    function findPlacemarks(obj) {
      if (!obj) return;
      
      if (obj.Placemark) {
        const placemarks = Array.isArray(obj.Placemark) ? obj.Placemark : [obj.Placemark];
        
        placemarks.forEach(placemark => {
          if (placemark.LineString && placemark.LineString.coordinates) {
            // Track line
            const coordString = placemark.LineString.coordinates.trim();
            const coords = coordString.split(/\s+/).map(coord => {
              const [lon, lat, alt] = coord.split(',').map(Number);
              return [lon, lat];
            });

            features.push({
              type: 'Feature',
              properties: {
                name: placemark.name || 'Track',
                description: placemark.description || ''
              },
              geometry: {
                type: 'LineString',
                coordinates: coords
              }
            });
          } else if (placemark.Point && placemark.Point.coordinates) {
            // Track point
            const coordString = placemark.Point.coordinates.trim();
            const [lon, lat] = coordString.split(',').map(Number);

            // Extract intensity information
            const description = placemark.description || '';
            const properties = {
              name: placemark.name || 'Forecast Position',
              description: description,
              datetime: placemark.dtg || placemark.name || '',
              stormType: placemark.stormType || '',
              intensity: placemark.intensity ? parseInt(placemark.intensity) : null,
              intensityMPH: placemark.intensityMPH ? parseInt(placemark.intensityMPH) : null,
              minSeaLevelPres: placemark.minSeaLevelPres ? parseInt(placemark.minSeaLevelPres) : null,
              stormName: placemark.stormName || '',
              basin: placemark.basin || ''
            };

            // Parse wind speed and other data from description if available
            if (description) {
              // Extract wind speed in knots
              const windMatch = description.match(/Maximum Wind:\s*(\d+)\s*knots/);
              if (windMatch) {
                properties.intensity = parseInt(windMatch[1]);
              }
              
              // Extract wind speed in mph
              const windMphMatch = description.match(/Maximum Wind:\s*\d+\s*knots\s*\((\d+)\s*mph\)/);
              if (windMphMatch) {
                properties.intensityMPH = parseInt(windMphMatch[1]);
              }
              
              // Extract pressure
              const pressureMatch = description.match(/Minimum Pressure:\s*(\d+)\s*mb/);
              if (pressureMatch) {
                properties.minSeaLevelPres = parseInt(pressureMatch[1]);
              }
              
              // Extract valid time/forecast hour
              const timeMatch = description.match(/Valid at:\s*([^<]+)/);
              if (timeMatch) {
                properties.datetime = timeMatch[1].trim();
              }
              
              // Extract forecast hour
              const forecastMatch = description.match(/(\d+)\s*hr\s*Forecast/);
              if (forecastMatch) {
                properties.forecastHour = parseInt(forecastMatch[1]);
              }
            }

            // Determine intensity category and display text
            if (placemark.styleUrl) {
              const style = placemark.styleUrl.replace('#', '');
              properties.styleCategory = style;
              
              // Map style to display category based on NHC KMZ style patterns
              switch (style) {
                case 'initial_point':
                  properties.category = 'NOW';
                  break;
                case 'xd_point':
                case 'd_point':
                  properties.category = 'TD';
                  break;
                case 'xs_point':
                case 's_point':
                  properties.category = 'TS';
                  break;
                case 'xh_point':
                case 'h_point':
                  properties.category = '1-2';
                  break;
                case 'xm_point':
                case 'm_point':
                  properties.category = '3-5';
                  break;
                case 'td':
                  properties.category = 'TD';
                  break;
                case 'ts':
                  properties.category = 'TS';
                  break;
                case 'cat1':
                  properties.category = '1';
                  break;
                case 'cat2':
                  properties.category = '2';
                  break;
                case 'cat3':
                  properties.category = '3';
                  break;
                case 'cat4':
                  properties.category = '4';
                  break;
                case 'cat5':
                  properties.category = '5';
                  break;
                case 'ex':
                  properties.category = 'EX';
                  break;
                default:
                  properties.category = style.toUpperCase();
              }
            }
            
            // Refine intensity category based on actual wind speed if available
            if (properties.intensity) {
              const windKnots = properties.intensity;
              if (windKnots < 34) {
                properties.category = 'TD';
              } else if (windKnots < 64) {
                properties.category = 'TS';
              } else if (windKnots < 83) {
                properties.category = '1';
              } else if (windKnots < 96) {
                properties.category = '2';
              } else if (windKnots < 113) {
                properties.category = '3';
              } else if (windKnots < 137) {
                properties.category = '4';
              } else {
                properties.category = '5';
              }
            }

            features.push({
              type: 'Feature',
              properties: properties,
              geometry: {
                type: 'Point',
                coordinates: [lon, lat]
              }
            });
          }
        });
      }

      // Recursively search in folders
      if (obj.Folder) {
        const folders = Array.isArray(obj.Folder) ? obj.Folder : [obj.Folder];
        folders.forEach(findPlacemarks);
      }
      
      if (obj.Document) {
        findPlacemarks(obj.Document);
      }
    }

    if (result.kml) {
      findPlacemarks(result.kml);
    }

    return {
      type: 'FeatureCollection',
      features: features,
      source: 'kmz'
    };

  } catch (error) {
    console.error('Error parsing KML for track:', error);
    throw error;
  }
}

/**
 * Parse KMZ file and extract cone data as GeoJSON
 */
async function parseKmzToConeGeoJSON(kmzBuffer) {
  return new Promise((resolve, reject) => {
    yauzl.fromBuffer(kmzBuffer, { lazyEntries: true }, (err, zipfile) => {
      if (err) {
        console.error('Error opening KMZ file for cone:', err);
        return reject(err);
      }

      let kmlContent = '';
      
      zipfile.readEntry();
      zipfile.on('entry', (entry) => {
        if (entry.fileName.toLowerCase().endsWith('.kml')) {
          zipfile.openReadStream(entry, (err, readStream) => {
            if (err) {
              console.error('Error reading KML from cone KMZ:', err);
              return reject(err);
            }

            const chunks = [];
            readStream.on('data', (chunk) => chunks.push(chunk));
            readStream.on('end', () => {
              kmlContent = Buffer.concat(chunks).toString('utf8');
              zipfile.readEntry();
            });
            readStream.on('error', reject);
          });
        } else {
          zipfile.readEntry();
        }
      });

      zipfile.on('end', () => {
        if (!kmlContent) {
          return reject(new Error('No KML file found in cone KMZ'));
        }

        // Parse KML and extract cone data
        extractConeFromKML(kmlContent)
          .then(resolve)
          .catch(reject);
      });

      zipfile.on('error', reject);
    });
  });
}

/**
 * Extract cone data from KML content
 */
async function extractConeFromKML(kmlContent) {
  try {
    const parser = new xml2js.Parser({ explicitArray: false });
    const result = await parser.parseStringPromise(kmlContent);

    // Find cone polygons in KML
    const features = [];
    
    function findConePolygons(obj) {
      if (!obj) return;
      
      if (obj.Placemark) {
        const placemarks = Array.isArray(obj.Placemark) ? obj.Placemark : [obj.Placemark];
        
        placemarks.forEach(placemark => {
          if (placemark.Polygon && placemark.Polygon.outerBoundaryIs) {
            // Extract polygon coordinates
            const outerRing = placemark.Polygon.outerBoundaryIs.LinearRing;
            if (outerRing && outerRing.coordinates) {
              const coordString = outerRing.coordinates.trim();
              const coords = coordString.split(/\s+/).map(coord => {
                const [lon, lat, alt] = coord.split(',').map(Number);
                return [lon, lat];
              });

              features.push({
                type: 'Feature',
                properties: {
                  name: placemark.name || 'Forecast Cone',
                  description: placemark.description || ''
                },
                geometry: {
                  type: 'Polygon',
                  coordinates: [coords]
                }
              });
            }
          }
        });
      }

      // Recursively search in folders
      if (obj.Folder) {
        const folders = Array.isArray(obj.Folder) ? obj.Folder : [obj.Folder];
        folders.forEach(findConePolygons);
      }
      
      if (obj.Document) {
        findConePolygons(obj.Document);
      }
    }

    if (result.kml) {
      findConePolygons(result.kml);
    }

    return {
      type: 'FeatureCollection',
      features: features,
      source: 'kmz'
    };

  } catch (error) {
    console.error('Error parsing KML for cone:', error);
    throw error;
  }
}

/**
 * Parse KMZ file and extract storm surge data as GeoJSON
 */
async function parseKmzToSurgeGeoJSON(kmzBuffer) {
  return new Promise((resolve, reject) => {
    yauzl.fromBuffer(kmzBuffer, { lazyEntries: true }, (err, zipfile) => {
      if (err) {
        console.error('Error opening KMZ file for storm surge:', err);
        return reject(err);
      }

      let kmlContent = '';
      
      zipfile.readEntry();
      zipfile.on('entry', (entry) => {
        if (entry.fileName.toLowerCase().endsWith('.kml')) {
          zipfile.openReadStream(entry, (err, readStream) => {
            if (err) {
              console.error('Error reading KML from storm surge KMZ:', err);
              return reject(err);
            }

            const chunks = [];
            readStream.on('data', (chunk) => chunks.push(chunk));
            readStream.on('end', () => {
              kmlContent = Buffer.concat(chunks).toString('utf8');
              zipfile.readEntry();
            });
            readStream.on('error', reject);
          });
        } else {
          zipfile.readEntry();
        }
      });

      zipfile.on('end', () => {
        if (!kmlContent) {
          return reject(new Error('No KML file found in storm surge KMZ'));
        }

        // Parse KML and extract storm surge data
        extractSurgeFromKML(kmlContent)
          .then(resolve)
          .catch(reject);
      });

      zipfile.on('error', reject);
    });
  });
}

/**
 * Extract storm surge data from KML content
 */
async function extractSurgeFromKML(kmlContent) {
  try {
    const parser = new xml2js.Parser({ explicitArray: false });
    const result = await parser.parseStringPromise(kmlContent);

    // Find storm surge polygons in KML
    const features = [];
    
    function findSurgePolygons(obj) {
      if (!obj) return;
      
      if (obj.Placemark) {
        const placemarks = Array.isArray(obj.Placemark) ? obj.Placemark : [obj.Placemark];
        
        placemarks.forEach(placemark => {
          if (placemark.Polygon && placemark.Polygon.outerBoundaryIs) {
            // Extract polygon coordinates
            const outerRing = placemark.Polygon.outerBoundaryIs.LinearRing;
            if (outerRing && outerRing.coordinates) {
              const coordString = outerRing.coordinates.trim();
              const coords = coordString.split(/\s+/).map(coord => {
                const [lon, lat, alt] = coord.split(',').map(Number);
                return [lon, lat];
              });

              // Extract storm surge height from placemark name or description
              let surgeHeight = 0;
              const name = placemark.name || '';
              const description = placemark.description || '';
              
              // Try to extract surge height from name (e.g., "3-6 ft", "6-9 ft")
              const heightMatch = name.match(/(\d+)-(\d+)\s*ft/i) || description.match(/(\d+)-(\d+)\s*ft/i);
              if (heightMatch) {
                surgeHeight = parseInt(heightMatch[2]); // Use upper bound
              }

              features.push({
                type: 'Feature',
                properties: {
                  name: placemark.name || 'Storm Surge Area',
                  description: placemark.description || '',
                  SURGE_FT: surgeHeight,
                  height: surgeHeight
                },
                geometry: {
                  type: 'Polygon',
                  coordinates: [coords]
                }
              });
            }
          }
        });
      }

      // Recursively search in folders
      if (obj.Folder) {
        const folders = Array.isArray(obj.Folder) ? obj.Folder : [obj.Folder];
        folders.forEach(findSurgePolygons);
      }
      
      if (obj.Document) {
        findSurgePolygons(obj.Document);
      }
    }

    if (result.kml) {
      findSurgePolygons(result.kml);
    }

    return {
      type: 'FeatureCollection',
      features: features,
      source: 'kmz'
    };

  } catch (error) {
    console.error('Error parsing KML for storm surge:', error);
    throw error;
  }
}

/**
 * Lambda handler for NHC API proxy
 */
exports.handler = async (event) => {
  console.log('NHC Proxy Lambda invoked:', JSON.stringify(event, null, 2));

  // Handle CORS preflight requests
  if (event.httpMethod === 'OPTIONS') {
    return {
      statusCode: 200,
      headers: corsHeaders,
      body: JSON.stringify({ message: 'CORS preflight response' })
    };
  }

  try {
    // Extract parameters from the request
    const { httpMethod, pathParameters, queryStringParameters } = event;
    
    if (httpMethod !== 'GET') {
      return {
        statusCode: 405,
        headers: corsHeaders,
        body: JSON.stringify({ error: 'Method not allowed. Only GET requests are supported.' })
      };
    }

    // Determine which NHC endpoint to call based on path
    const endpoint = pathParameters?.proxy || 'active-storms';
    let nhcUrl;
    let isKmzEndpoint = false;
    
    switch (endpoint) {
      case 'active-storms':
        nhcUrl = `${NHC_BASE_URL}/CurrentStorms.json`;
        break;
        
      case 'track-kmz':
        const trackStormId = queryStringParameters?.stormId;
        const trackYear = queryStringParameters?.year || new Date().getFullYear();
        if (!trackStormId) {
          return {
            statusCode: 400,
            headers: corsHeaders,
            body: JSON.stringify({ error: 'stormId parameter is required for track-kmz endpoint' })
          };
        }
        nhcUrl = `${NHC_BASE_URL}/gis/best_track/${trackStormId.toLowerCase()}_best_track.kmz`;
        isKmzEndpoint = true;
        break;
        
      case 'forecast-track':
        const stormId = queryStringParameters?.stormId;
        const year = queryStringParameters?.year || new Date().getFullYear();
        if (!stormId) {
          return {
            statusCode: 400,
            headers: corsHeaders,
            body: JSON.stringify({ error: 'stormId parameter is required for forecast-track endpoint' })
          };
        }
        nhcUrl = `${NHC_BASE_URL}/gis/forecast/archive/${year}/${stormId.toUpperCase()}_5day_latest.geojson`;
        break;
        
      case 'historical-track':
        const histStormId = queryStringParameters?.stormId;
        const histYear = queryStringParameters?.year || new Date().getFullYear();
        if (!histStormId) {
          return {
            statusCode: 400,
            headers: corsHeaders,
            body: JSON.stringify({ error: 'stormId parameter is required for historical-track endpoint' })
          };
        }
        nhcUrl = `${NHC_BASE_URL}/gis/best_track/archive/${histYear}/${histStormId.toUpperCase()}_best_track.geojson`;
        break;
        
      case 'forecast-cone':
        const coneStormId = queryStringParameters?.stormId;
        if (!coneStormId) {
          return {
            statusCode: 400,
            headers: corsHeaders,
            body: JSON.stringify({ error: 'stormId parameter is required for forecast-cone endpoint' })
          };
        }
        
        // Use the storm graphics API cone URL format
        nhcUrl = `https://www.nhc.noaa.gov/storm_graphics/api/${coneStormId.toUpperCase()}_CONE_latest.kmz`;
        isKmzEndpoint = true;
        console.log(`Using cone URL: ${nhcUrl}`);
        break;
        
      case 'forecast-track-kmz':
        const forecastStormId = queryStringParameters?.stormId;
        if (!forecastStormId) {
          return {
            statusCode: 400,
            headers: corsHeaders,
            body: JSON.stringify({ error: 'stormId parameter is required for forecast-track-kmz endpoint' })
          };
        }
        // Use the forecast track KMZ format: EP092025_TRACK_latest.kmz
        nhcUrl = `${NHC_BASE_URL}/storm_graphics/api/${forecastStormId.toUpperCase()}_TRACK_latest.kmz`;
        isKmzEndpoint = true;
        break;
        
      case 'storm-surge':
        const surgeStormId = queryStringParameters?.stormId;
        if (!surgeStormId) {
          return {
            statusCode: 400,
            headers: corsHeaders,
            body: JSON.stringify({ error: 'stormId parameter is required for storm-surge endpoint' })
          };
        }
        
        // Storm surge is primarily available for Atlantic storms (AL prefix)
        if (!surgeStormId.toUpperCase().startsWith('AL')) {
          return {
            statusCode: 200,
            headers: corsHeaders,
            body: JSON.stringify({
              success: false,
              message: 'Storm surge data is typically only available for Atlantic storms (AL prefix)',
              stormId: surgeStormId,
              timestamp: new Date().toISOString()
            })
          };
        }
        
        // Use the storm surge KMZ format
        nhcUrl = `${NHC_BASE_URL}/storm_graphics/api/${surgeStormId.toUpperCase()}_PeakStormSurge_latest.kmz`;
        isKmzEndpoint = true;
        break;
        
      default:
        return {
          statusCode: 400,
          headers: corsHeaders,
          body: JSON.stringify({ 
            error: 'Invalid endpoint. Supported endpoints: active-storms, track-kmz, forecast-track, historical-track, forecast-cone, forecast-track-kmz, storm-surge' 
          })
        };
    }

    console.log(`Fetching data from NHC: ${nhcUrl}`);

    // Make the request to NHC API
    const axiosConfig = {
      timeout: 20000,
      headers: {
        'User-Agent': 'StormCast Pro (cyclotrak.com, jasonprice70@gmail.com)',
        'Accept': isKmzEndpoint ? 'application/vnd.google-earth.kmz' : 'application/json'
      }
    };

    if (isKmzEndpoint) {
      axiosConfig.responseType = 'arraybuffer';
    }

    const response = await axios.get(nhcUrl, axiosConfig);

    console.log(`NHC API response status: ${response.status}`);

    let responseData;

    if (isKmzEndpoint) {
      // Parse KMZ to GeoJSON - handle both track and cone data
      try {
        if (endpoint === 'track-kmz' || endpoint === 'forecast-track-kmz') {
          responseData = await parseKmzToTrackGeoJSON(response.data);
          console.log(`Successfully parsed KMZ track data with ${responseData.features.length} features`);
        } else if (endpoint === 'forecast-cone') {
          responseData = await parseKmzToConeGeoJSON(response.data);
          console.log(`Successfully parsed KMZ cone data with ${responseData.features.length} features`);
        } else if (endpoint === 'storm-surge') {
          responseData = await parseKmzToSurgeGeoJSON(response.data);
          console.log(`Successfully parsed KMZ storm surge data with ${responseData.features.length} features`);
        } else {
          throw new Error(`Unknown KMZ endpoint: ${endpoint}`);
        }
      } catch (parseError) {
        console.error(`Error parsing KMZ ${endpoint} data:`, parseError);
        return {
          statusCode: 500,
          headers: corsHeaders,
          body: JSON.stringify({
            success: false,
            error: `Failed to parse KMZ ${endpoint} data`,
            details: parseError.message,
            endpoint: endpoint,
            timestamp: new Date().toISOString()
          })
        };
      }
    } else {
      responseData = response.data;
    }

    // Return successful response
    return {
      statusCode: 200,
      headers: corsHeaders,
      body: JSON.stringify({
        success: true,
        data: responseData,
        endpoint: endpoint,
        timestamp: new Date().toISOString()
      })
    };

  } catch (error) {
    console.error('Error proxying NHC request:', error);

    // Handle specific error types
    let statusCode = 500;
    let errorMessage = 'Internal server error';

    if (error.response) {
      // NHC API responded with an error
      statusCode = error.response.status;
      if (statusCode === 404) {
        errorMessage = 'Data not found (this is normal if no data is available for this storm/time period)';
      } else {
        errorMessage = `NHC API error: ${error.response.statusText}`;
      }
    } else if (error.code === 'ECONNABORTED') {
      statusCode = 408;
      errorMessage = 'Request timeout while fetching data from NHC';
    } else if (error.code === 'ENOTFOUND' || error.code === 'ECONNREFUSED') {
      statusCode = 503;
      errorMessage = 'Unable to connect to NHC API';
    }

    return {
      statusCode: statusCode,
      headers: corsHeaders,
      body: JSON.stringify({
        success: false,
        error: errorMessage,
        endpoint: event.pathParameters?.proxy || 'unknown',
        timestamp: new Date().toISOString()
      })
    };
  }
};
